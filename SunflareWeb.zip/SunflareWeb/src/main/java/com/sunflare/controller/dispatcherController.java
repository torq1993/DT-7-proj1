package com.sunflare.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class dispatcherController{
	   
	   @RequestMapping("/aboutUs")
	   public String aboutUs(ModelMap model){
		   return "aboutUs";
	   }
	   
	   @RequestMapping("/login")
	   public String login(){
		   return "login";
	   }
	   
	   @RequestMapping("/register")
	   public String register(){
		   return "register";
	   }
	   
	   @RequestMapping("/contactus")
	   public String contactus(){
		   return "contactus";
	   }

}