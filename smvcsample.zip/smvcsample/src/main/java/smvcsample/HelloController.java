package smvcsample;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HelloController {
	@RequestMapping(value = "/loggedin", method = RequestMethod.POST)
	   public String addStudent(@ModelAttribute("smvcsample")user student, 
	   ModelMap model) {
	      model.addAttribute("name", student.getName());
	      model.addAttribute("pass", student.getPass());
	      return "helloworld";
	   }
}
