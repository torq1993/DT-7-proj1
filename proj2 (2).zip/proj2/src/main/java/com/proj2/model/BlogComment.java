package com.proj2.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class BlogComment {
	@Id
	@GeneratedValue
	private long blog_comm_id;
	@Column
	private long blog_id;
	@Column
	private String user_name;
	@Column
	private String content;
	@Column
	private Date commdate;
	
	public Date getCommdate() {
		return commdate;
	}
	public void setCommdate(Date commdate) {
		this.commdate = commdate;
	}
	public long getBlog_id() {
		return blog_id;
	}
	public void setBlog_id(long blog_id) {
		this.blog_id = blog_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public long getBlog_comm_id() {
		return blog_comm_id;
	}
	public void setBlog_comm_id(long blog_comm_id) {
		this.blog_comm_id = blog_comm_id;
	}
	
}
