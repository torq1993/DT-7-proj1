package com.proj2.service;

import java.util.List;

import com.proj2.model.Blog;
import com.proj2.model.Forum;

public interface blogService {

	 List<Blog> getAllBlogs();
	 Blog getBlog(long id);
	 void postBlog(Blog blog);
	 void updateBlog(Blog blog);
	 void deleteBlog(long id);
}
