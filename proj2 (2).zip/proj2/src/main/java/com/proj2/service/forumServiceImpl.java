package com.proj2.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proj2.model.Forum;

@Service("forumserv")
public class forumServiceImpl implements forumService {

	@Autowired
	SessionFactory getSessionFactory;
	
	@Override
	public Forum getForum(long id) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		Query query = session.createQuery("FROM Forum WHERE id = :id");
		query.setParameter("id", id);
		Forum forum = new Forum();
		forum = (Forum) query.getSingleResult();
		session.close();
		return forum;
	}

	@Override
	public void updateForum(Forum forum) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.update(forum);
		tx.commit();
		session.close();
	}

	@Override
	public void deleteForum(long id) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("DELETE FROM Forum WHERE id = :id");
		query.setParameter("id", id);
		query.executeUpdate();
		tx.commit();
		session.close();
	}

	@Override
	public List<Forum> getAllForums() {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		List<Forum> list= new ArrayList<Forum>();
		list = session.createQuery("FROM Forum").getResultList();
		session.close();
		return list;
	}

	@Override
	public void postForum(Forum forum) {
		// TODO Auto-generated method stub
		forum.setForumdate(new Date());
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(forum);
		tx.commit();
		session.close();
		
	}

}
