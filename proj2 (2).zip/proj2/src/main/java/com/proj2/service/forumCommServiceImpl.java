package com.proj2.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proj2.model.ForumComment;

@Service("forumcommserv")
public class forumCommServiceImpl implements forumCommService {

	@Autowired
	SessionFactory getSessionFactory;
	
	@Override
	public List<ForumComment> fetchAllComments(long id) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		List<ForumComment> list = new ArrayList<ForumComment>();
		Query query = session.createQuery("FROM ForumComment WHERE forum_id = :id");
		query.setParameter("id", id);
		list = query.getResultList();
		return list;
	}

	@Override
	public void postComment(ForumComment forumComm) {
		// TODO Auto-generated method stub
		forumComm.setCommdate(new Date());
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(forumComm);
		tx.commit();
		session.close();
	}

	@Override
	public void deleteComment(long id, long cid) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("DELETE FROM ForumComment WHERE forum_id = :id AND forum_comm_id = :cid");
		query.setParameter("id", id);
		query.setParameter("cid", cid);
		query.executeUpdate();
		tx.commit();
		session.close();
	}

	@Override
	public void editComment(long id, long cid, String comment) {
		// TODO Auto-generated method stub
		ForumComment editedComm = new ForumComment();
		ForumComment oldComm = new ForumComment();
		oldComm = fetchComment(cid);
		editedComm.setForum_comm_id(cid);
		editedComm.setForum_id(id);
		editedComm.setContent(comment);
		editedComm.setUser_name(oldComm.getUser_name());
		editedComm.setCommdate(new Date());
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.update(editedComm);
		tx.commit();
		session.close();
	}

	@Override
	public ForumComment fetchComment(long id) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		ForumComment comm = new ForumComment();
		Query query = session.createQuery("FROM ForumComment WHERE forum_comm_id = :id");
		query.setParameter("id", id);
		comm = (ForumComment) query.getSingleResult();
		return comm;
	}

}
