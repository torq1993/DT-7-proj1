package com.proj2.service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.Query;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Service;

import com.proj2.model.EmailVerif;
import com.proj2.model.User;
import com.proj2.model.UserCred;

@Service("userserv")
public class userServiceImpl implements userService {

	@Autowired
	SessionFactory getSessionFactory;
	
	public List<User> findAllUsers() {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		List<User> clist = new ArrayList<User>();
		clist = session.createQuery("FROM Users").getResultList();
		session.close();
		return clist;
	}

	public User findById(long id) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		User clist = new User();
		Query query = session.createQuery("FROM Users WHERE id = :id");
		query.setParameter("id", id);
		clist = (User) query.getSingleResult();
		session.close();
		return clist;
	}

	public UserCred findByName(String name) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		UserCred user = new UserCred();
		Query query = session.createQuery("FROM UserCred WHERE username = :name");
		query.setParameter("name", name);
		user = (UserCred) query.getSingleResult();
		session.close();
		System.out.println("User credentials username "+user.getUsername());
		System.out.println("User credentials password "+user.getPassword());
		return user;
	}

	public boolean isUserExist(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	public void saveUser(User user) {
		// TODO Auto-generated method stub
		UserCred userCred = new UserCred();
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		userCred.setUsername(user.getUsername());
		userCred.setPassword(user.getPassword());
		session.save(userCred);
		session.save(user);
		tx.commit();
		session.close();

	}

	public void deleteUser(long id) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("DELETE FROM Users WHERE id = :id");
		query.setParameter("id", id);
		query.executeUpdate();
		tx.commit();
		session.close();
		
	}

	public void updateUser(User user) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("UPDATE Users SET email = :email, username = :username WHERE id = :id");
		query.setParameter("email", user.getEmail());
		query.setParameter("username", user.getUsername());
		query.setParameter("id", user.getId());
		query.executeUpdate();
		tx.commit();
		session.close();

	}
	public UserCred authUser(UserCred userCred) {
		// TODO Auto-generated method stub
		UserCred user = new UserCred();
		user = findByName(userCred.getUsername());
		System.out.println("User password "+userCred.getPassword());
		System.out.println("UserCred password "+user.getPassword());
		if(user.getPassword().compareTo(userCred.getPassword()) != 0)
		{
			return null;
			
		}
		return userCred;
	}

	@Override
	public List<UserCred> findAllUserCred() {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		List<UserCred> clist = new ArrayList<UserCred>();
		clist = session.createQuery("FROM UserCred").getResultList();
		session.close();
		return clist;
	}

	@Override
	public void confEmail(User user) throws EmailException {
		// TODO Auto-generated method stub
		String uuid = UUID.randomUUID().toString();
		Email email = new SimpleEmail();
		addTempUser(uuid,user);
		email.setHostName("smtp.googlemail.com");
		email.setSmtpPort(465);
		email.setSSLOnConnect(true);
		email.setFrom("torqsama1993@gmail.com");
		email.setAuthenticator(new DefaultAuthenticator("torqsama1993@gmail.com", "urfrndbkram1993"));
		email.setSubject("test");
		email.setMsg("http://localhost:8480/proj2FrontEnd/#/adduser/"+uuid);
		email.addTo(user.getEmail());
		email.send();
	}

	@Override
	public void addTempUser(String uuid,User user) {
		// TODO Auto-generated method stub
		EmailVerif temp = new EmailVerif();
		temp.setUuid(uuid);
		temp.setUsername(user.getUsername());
		temp.setEmail(user.getEmail());
		temp.setPassword(user.getPassword());
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(temp);
		tx.commit();
		session.close();

		
	}

	@Override
	public EmailVerif findById(String uuid) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		EmailVerif clist = new EmailVerif();
		Query query = session.createQuery("FROM EmailVerif WHERE uuid = :id");
		query.setParameter("id", uuid);
		clist = (EmailVerif)query.getSingleResult();
		session.close();
		return clist;
	}

}
