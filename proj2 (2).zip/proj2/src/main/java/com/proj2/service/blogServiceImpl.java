package com.proj2.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proj2.model.Blog;

@Service("blogserv")
public class blogServiceImpl implements blogService {

	@Autowired
	SessionFactory getSessionFactory;
	public List<Blog> getAllBlogs() {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		List<Blog> list = new ArrayList<Blog>();
		list = session.createQuery("FROM Blog").getResultList();
		session.close();
		return list;
	}

	public Blog getBlog(long id) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		Blog blog = new Blog();
		Query query = session.createQuery("FROM Blog WHERE blog_id = :id");
		query.setParameter("id", id);
		blog = (Blog) query.getSingleResult();
		session.close();
		return blog;
	}

	@Override
	public void postBlog(Blog blog) {
		// TODO Auto-generated method stub
		blog.setBlogdate(new Date());
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(blog);
		tx.commit();
		session.close();
	}

	@Override
	public void deleteBlog(long id) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Query query1 = session.createQuery("DELETE FROM Blog WHERE blog_id = :id");
		Query query2 = session.createQuery("DELETE FROM BlogComment WHERE blog_id = :id");
		query1.setParameter("id", id);
		query2.setParameter("id", id);
		query1.executeUpdate();
		query2.executeUpdate();
		tx.commit();
		session.close();		
	}

	@Override
	public void updateBlog(Blog blog) {
		// TODO Auto-generated method stub
		blog.setBlogdate(new Date());
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.update(blog);
		tx.commit();
		session.close();
	}

}
