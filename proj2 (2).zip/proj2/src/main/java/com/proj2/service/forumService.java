package com.proj2.service;

import java.util.List;

import com.proj2.model.Blog;
import com.proj2.model.Forum;

public interface forumService {

	List<Forum> getAllForums();
	Forum getForum(long id);
	void postForum(Forum forum);
	void updateForum(Forum forum);
	void deleteForum(long id);
	
}
