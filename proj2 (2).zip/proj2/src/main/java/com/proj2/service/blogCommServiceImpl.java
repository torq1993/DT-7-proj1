package com.proj2.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.Transient;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.proj2.model.BlogComment;

@Service("blogcommserv")
public class blogCommServiceImpl implements blogCommService {

	@Autowired
	SessionFactory getSessionFactory;
	
	@Override
	public List<BlogComment> fetchAllComments(long id) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		List<BlogComment> list = new ArrayList<BlogComment>();
		Query query = session.createQuery("FROM BlogComment WHERE blog_id = :id");
		query.setParameter("id", id);
		list = query.getResultList();
		return list;
	}

	@Override
	public void postComment(BlogComment blogComm) {
		// TODO Auto-generated method stub
		blogComm.setCommdate(new Date());
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(blogComm);
		tx.commit();
		session.close();
		
	}

	@Override
	public void deleteComment(long id,long cid) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("DELETE FROM BlogComment WHERE blog_id = :id AND blog_comm_id = :cid");
		query.setParameter("id", id);
		query.setParameter("cid", cid);
		query.executeUpdate();
		tx.commit();
		session.close();

	}

	@Override
	public void editComment(long id, long cid, String comment) {
		// TODO Auto-generated method stub
		BlogComment editedComm = new BlogComment();
		BlogComment oldComm = new BlogComment();
		oldComm = fetchComment(cid);
		editedComm.setBlog_comm_id(cid);
		editedComm.setBlog_id(id);
		editedComm.setContent(comment);
		editedComm.setUser_name(oldComm.getUser_name());
		editedComm.setCommdate(new Date());
		Session session = getSessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.update(editedComm);
		tx.commit();
		session.close();
		
	}

	@Override
	public BlogComment fetchComment(long id) {
		// TODO Auto-generated method stub
		Session session = getSessionFactory.openSession();
		BlogComment comm = new BlogComment();
		Query query = session.createQuery("FROM BlogComment WHERE blog_comm_id = :id");
		query.setParameter("id", id);
		comm = (BlogComment) query.getSingleResult();
		return comm;
	}

}
