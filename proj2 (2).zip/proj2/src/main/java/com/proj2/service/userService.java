package com.proj2.service;

import java.util.List;

import org.apache.commons.mail.EmailException;

import com.proj2.model.EmailVerif;
import com.proj2.model.User;
import com.proj2.model.UserCred;

public interface userService {

	List<User> findAllUsers();
	List<UserCred> findAllUserCred();
	User findById(long id);
	UserCred findByName(String name);
	void saveUser(User user);
	void deleteUser(long id);
	void updateUser(User user);
	public boolean isUserExist(User user);
	UserCred authUser(UserCred userCred);
	void confEmail(User user) throws EmailException;
	void addTempUser(String uuid,User user);
	EmailVerif findById(String uuid);
}
