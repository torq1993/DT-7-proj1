package com.proj2.service;

import java.util.List;

import com.proj2.model.BlogComment;
import com.proj2.model.ForumComment;

public interface forumCommService {
	List<ForumComment> fetchAllComments(long id);
	ForumComment fetchComment(long id);
	void postComment(ForumComment forumComm);
	void deleteComment(long id, long cid);
	void editComment(long id, long cid, String comment);
}
