package com.proj2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.proj2.model.Blog;
import com.proj2.model.BlogComment;
import com.proj2.service.blogCommService;
import com.proj2.service.blogService;

@RestController
public class blogController {

	@Autowired
	blogService blogserv;
	@Autowired
	blogCommService blogcommserv;
	
	
	@RequestMapping(value="/blogs/{id}", method=RequestMethod.GET)
	public ResponseEntity<Blog> getBlog(@PathVariable("id") long blog_id)
	{
		Blog blog = blogserv.getBlog(blog_id);
		return new ResponseEntity<Blog>(blog, HttpStatus.OK);
	}
	@RequestMapping(value ="/blogs/{id}", method=RequestMethod.PUT)
	public ResponseEntity<List<Blog>> editBlog(@RequestBody Blog blog)
	{
		blogserv.updateBlog(blog);
		return new ResponseEntity<List<Blog>>(HttpStatus.OK);
	}
	@RequestMapping(value ="/blogs/", method=RequestMethod.GET)
	public ResponseEntity<List<Blog>> getBlogs()
	{
		List<Blog> blogs = blogserv.getAllBlogs();
		return new ResponseEntity<List<Blog>>(blogs, HttpStatus.OK);
	}
	@RequestMapping(value ="/blogs/", method=RequestMethod.POST)
	public ResponseEntity<Blog> postBlog(@RequestBody Blog blog)
	{
		blogserv.postBlog(blog);
		return new ResponseEntity<Blog>(HttpStatus.CREATED);
	}
	@RequestMapping(value ="/blogs/{id}", method=RequestMethod.DELETE)
	public ResponseEntity<List<BlogComment>> deleteBlog(@PathVariable("id") long id)
	{
		blogserv.deleteBlog(id);
		return new ResponseEntity<List<BlogComment>>(HttpStatus.OK);
	}
	@RequestMapping(value ="/blogs/{id}/comm/", method=RequestMethod.GET)
	public ResponseEntity<List<BlogComment>> getComments(@PathVariable("id") long id)
	{
		List<BlogComment> comments = blogcommserv.fetchAllComments(id);
		return new ResponseEntity<List<BlogComment>>(comments, HttpStatus.OK);
	}
	@RequestMapping(value ="/blogs/{id}/comm/", method=RequestMethod.POST)
	public ResponseEntity<BlogComment> postComment(@RequestBody BlogComment blogComm)
	{
		blogcommserv.postComment(blogComm);
		return new ResponseEntity<BlogComment>(HttpStatus.CREATED);
	}
	@RequestMapping(value ="/blogs/{id}/comm/{cid}", method=RequestMethod.DELETE)
	public ResponseEntity<List<BlogComment>> deleteComment(@PathVariable("id") long id,@PathVariable("cid") long cid)
	{
		blogcommserv.deleteComment(id,cid);
		return new ResponseEntity<List<BlogComment>>(HttpStatus.OK);
	}
	@RequestMapping(value ="/blogs/{id}/comm/{cid}", method=RequestMethod.PUT)
	public ResponseEntity<List<BlogComment>> editComment(@PathVariable("id") long id,@PathVariable("cid") long cid, @RequestBody String comment)
	{
		blogcommserv.editComment(id,cid,comment);
		return new ResponseEntity<List<BlogComment>>(HttpStatus.OK);
	}
	
	
}
