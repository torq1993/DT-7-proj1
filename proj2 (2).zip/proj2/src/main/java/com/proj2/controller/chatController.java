package com.proj2.controller;

import java.util.Date;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.proj2.model.Message;
import com.proj2.model.OutputMessage;

@RestController
public class chatController {
	
	@MessageMapping("/chat")
	@SendTo("/topic/message")
	public OutputMessage sendMessage(@RequestBody Message message)
	{
		return new OutputMessage(message, new Date());
	}

}
