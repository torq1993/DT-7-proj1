package com.proj2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.proj2.model.Blog;
import com.proj2.model.BlogComment;
import com.proj2.model.Forum;
import com.proj2.model.ForumComment;
import com.proj2.service.forumCommService;
import com.proj2.service.forumService;

@RestController
public class forumController {
	@Autowired
	forumService forumserv;
	@Autowired
	forumCommService forumcommserv;
	
	@RequestMapping(value="/forums/{id}", method=RequestMethod.GET)
	public ResponseEntity<Forum> getForum(@PathVariable("id") long forum_id)
	{
		Forum forum = forumserv.getForum(forum_id);
		return new ResponseEntity<Forum>(forum, HttpStatus.OK);
	}
	@RequestMapping(value ="/forums/", method=RequestMethod.GET)
	public ResponseEntity<List<Forum>> getForums()
	{
		List<Forum> forums = forumserv.getAllForums();
		return new ResponseEntity<List<Forum>>(forums, HttpStatus.OK);
	}
	@RequestMapping(value ="/forums/", method=RequestMethod.POST)
	public ResponseEntity<Forum> postForum(@RequestBody Forum forum)
	{
		forumserv.postForum(forum);
		return new ResponseEntity<Forum>(HttpStatus.CREATED);
	}
	@RequestMapping(value ="/forums/{id}", method=RequestMethod.DELETE)
	public ResponseEntity<List<ForumComment>> deleteForum(@PathVariable("id") long id)
	{
		forumserv.deleteForum(id);
		return new ResponseEntity<List<ForumComment>>(HttpStatus.OK);
	}
	@RequestMapping(value ="/forums/{id}/comm/", method=RequestMethod.GET)
	public ResponseEntity<List<ForumComment>> getComments(@PathVariable("id") long id)
	{
		List<ForumComment> comments = forumcommserv.fetchAllComments(id);
		return new ResponseEntity<List<ForumComment>>(comments, HttpStatus.OK);
	}
	@RequestMapping(value ="/forums/{id}/comm/", method=RequestMethod.POST)
	public ResponseEntity<ForumComment> postComment(@RequestBody ForumComment forumComm)
	{
		forumcommserv.postComment(forumComm);
		return new ResponseEntity<ForumComment>(HttpStatus.CREATED);
	}
	@RequestMapping(value ="/forums/{id}/comm/{cid}", method=RequestMethod.DELETE)
	public ResponseEntity<List<ForumComment>> deleteComment(@PathVariable("id") long id,@PathVariable("cid") long cid)
	{
		forumcommserv.deleteComment(id,cid);
		return new ResponseEntity<List<ForumComment>>(HttpStatus.OK);
	}
	@RequestMapping(value ="/forums/{id}/comm/{cid}", method=RequestMethod.PUT)
	public ResponseEntity<List<ForumComment>> editComment(@PathVariable("id") long id,@PathVariable("cid") long cid, @RequestBody String comment)
	{
		forumcommserv.editComment(id,cid,comment);
		return new ResponseEntity<List<ForumComment>>(HttpStatus.OK);
	}
}
