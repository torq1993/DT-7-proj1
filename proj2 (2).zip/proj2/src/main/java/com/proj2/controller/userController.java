package com.proj2.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.mail.EmailException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

import com.proj2.model.EmailVerif;
import com.proj2.model.User;
import com.proj2.model.UserCred;
import com.proj2.service.userService;
import com.proj2.service.userServiceImpl;

@RestController
public class userController {

	@Autowired
	userService userserv;
	@Autowired
	SessionFactory getSessionFactory;
	
	@RequestMapping(value = "/pass", method = RequestMethod.GET)
	public void passUser(HttpServletRequest request,HttpServletResponse response)
	{
		String sn=request.getParameter("ver");
		Session session = getSessionFactory.openSession();
		Query query = session.createQuery("FROM Users WHERE username = :una");
		query.setParameter("una", sn);
		ArrayList<User> users = new ArrayList<User>();
		users= (ArrayList<User>) query.getResultList();
		if(!users.isEmpty())
        {    
            try {
			
				 response.getWriter().println("Name already taken");
		        
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
           

        }else {

        	try {
			
				response.getWriter().println("");
	        
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	

        }
		session.close();
	}
	
	@RequestMapping(value = "/user/", method = RequestMethod.GET)
	public ResponseEntity<List<User>> listAllUsers(){
		List<User> users = userserv.findAllUsers();
		if(users.isEmpty())
		{
			return new ResponseEntity<List<User>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<User>>(users, HttpStatus.OK);
	}
	@RequestMapping(value = "/user/{id}", method = RequestMethod.GET)
	public ResponseEntity<User> getUser(@PathVariable("id") long id)
	{
		System.out.println("Fetching User with id : "+id);
		User user = userserv.findById(id);
		if(user == null)
		{
			System.out.println("User with id "+id+" does not exist!");
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<User>(user, HttpStatus.OK);
	}
	@RequestMapping(value = "/adduser/{id}", method = RequestMethod.GET)
	public ResponseEntity<Void> addUser(@PathVariable("id") String uuid)
	{
		System.out.println("Fetching User with id : "+uuid);
		EmailVerif temp = userserv.findById(uuid);
		User user = new User();
		user.setEmail(temp.getEmail());
		user.setUsername(temp.getUsername());
		user.setPassword(temp.getPassword());
		userserv.saveUser(user);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	@RequestMapping(value = "/user/", method = RequestMethod.POST)
	public ResponseEntity<Void> createUser(@RequestBody User user)
	{
		System.out.println("Creating User "+user.getUsername());
		if(userserv.isUserExist(user))
		{
			System.out.println("User with name "+user.getUsername()+" already exist");
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}
		try {
			userserv.confEmail(user);
		} catch (EmailException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}
	@RequestMapping(value = "/user/{name}", method = RequestMethod.POST)
	public ResponseEntity<Void> uploadImage(@RequestParam(value = "file") MultipartFile img, @PathVariable("name") String name)
	{
		String path  = "C:\\Users\\Karthik\\Documents\\EclipseWorkspace\\Karthik\\proj2\\src\\main\\webapp\\resources\\img\\";
		path = path+name+".jpg";
		File f = new File(path);
		   if(!img.isEmpty())
		   {
			   System.out.println("Inside addproduct if\n");
			   try{
				   byte[] bytes = img.getBytes();
				   FileOutputStream fos = new FileOutputStream(f);
				   BufferedOutputStream bos = new BufferedOutputStream(fos);
				   bos.write(bytes);
				   bos.close();
			   }
			   catch(Exception e)
			   {
				   System.out.println("Exception Raised: "+e);
			   }
		   }
		   try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ResponseEntity<Void>(HttpStatus.CREATED);
	}
	@RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<User> deleteUser(@PathVariable("id") long id)
	{
		System.out.println("Deleting user with id "+id);
		User user = userserv.findById(id);
		if(user == null)
		{
			System.out.println("User with id "+id+" not found!");
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
		}
		userserv.deleteUser(id);
		return new ResponseEntity<User>(HttpStatus.OK);
	}
	@RequestMapping(value = "/user/{id}", method = RequestMethod.PUT)
	public ResponseEntity<User> updateUser(@PathVariable("id") long id, @RequestBody User user)
	{
		System.out.println("Updating User id "+id);
		User currentUser = userserv.findById(id);
		if(currentUser == null)
		{
			System.out.println("User id "+id+" not found!");
			return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
		}
		System.out.println("Updating User id "+currentUser.getId());
		currentUser.setUsername(user.getUsername());
		currentUser.setEmail(user.getEmail());
		
		userserv.updateUser(currentUser);
		return new ResponseEntity<User>(currentUser, HttpStatus.OK);
	}
	@RequestMapping(value = "/login/", method = RequestMethod.POST)
	public ResponseEntity<UserCred> authUser(@RequestBody UserCred userCred)
	{
		System.out.println("Authenticating User "+userCred.getUsername());
		UserCred loggedUser = new UserCred();
		loggedUser = userserv.authUser(userCred);
		if(loggedUser == null)
		{
			System.out.println("User credentials for "+userCred.getUsername()+" not correct!");
			return new ResponseEntity<UserCred>(HttpStatus.NOT_FOUND);
		}
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ResponseEntity<UserCred>(loggedUser, HttpStatus.OK);
		
	}
	@RequestMapping(value = "/login/", method = RequestMethod.GET)
	public ResponseEntity<List<UserCred>> listAllUserCred(){
		List<UserCred> users = userserv.findAllUserCred();
		if(users.isEmpty())
		{
			return new ResponseEntity<List<UserCred>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<UserCred>>(users, HttpStatus.OK);
	}
}
