/**
 * 
 */
'use strict';
angular.module('myApp').controller('UserController', ['$scope', 'UserService', function($scope, UserService){
	var self = this;
	self.user = {id:null, username:'', email:''};
	self.users =[];
	self.submit	= submit;
	
	fetchAllUsers();
	
	function fetchAllUsers(){
		UserService.fetchAllUsers()
			.then(function(d){
				self.users = d;
			},
				function(errResponse){
					console.error("Error While fetching Users");
			}
			);
	}
	function createUser(user){
		UserService.createUser(user)
			.then(fetchAllUsers,
					function(errResponse){
						console.error("Error While Creating User");
			}
			);
		}
	function submit(){
		if(self.user.id != null){
			console.log('saving new user', self.user);
			createUser(self.user);
		}
	}
}]);