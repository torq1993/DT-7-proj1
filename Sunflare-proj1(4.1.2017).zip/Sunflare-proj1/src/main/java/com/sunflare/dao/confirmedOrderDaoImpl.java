package com.sunflare.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sunflare.model.confirmedOrders;

import com.google.gson.Gson;

@Repository
public class confirmedOrderDaoImpl implements confirmedOrderDao {

	@Autowired
	SessionFactory sessionFactoryProduct;
	public String getList() {
		Session session = sessionFactoryProduct.openSession();
		List clist = new ArrayList();
		clist = session.createQuery("FROM confirmedOrders").getResultList();
		session.close();
		Gson gson = new Gson();
		String gsontojson = gson.toJson(clist);
		return gsontojson;
	}

	public void addOrder() {
		
		// TODO Auto-generated method stub

	}

	public void deleteOrder(int id) {
		// TODO Auto-generated method stub

	}

}
