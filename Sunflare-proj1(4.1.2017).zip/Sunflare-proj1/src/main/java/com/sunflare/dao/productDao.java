package com.sunflare.dao;

import com.sunflare.model.Product;

public interface productDao {
	public String getList();
	public void addProduct(Product product);
	public void deleteProduct(int id);
	public void editProduct(int id, Product product);
	public void updateProduct(Product tempProduct, Product product);
	public Product getProduct(int id);
}
