package com.sunflare.dao;

import com.sunflare.model.userInfo;

public interface confirmedOrderDao {
	public String getList();
	public void addOrder();
	public void deleteOrder(int id);
}
