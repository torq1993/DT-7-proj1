package com.sunflare.dao;

import java.util.List;

import com.sunflare.model.Supplier;

public interface supplierDao {
	public String getList();
	public void addSupplier(Supplier supplier);
	public void deleteSupplier(int id);
	public void editSupplier(int id, Supplier supplier);
	public void updateSupplier(Supplier tempSupplier, Supplier supplier);
	public Supplier getSupplier(int id);
}