package com.sunflare.dao;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sunflare.model.userConfirm;
import com.sunflare.model.userInfo;

@Repository
public class userConfirmDaoImpl implements userConfirmDao {

	
	@Autowired
	SessionFactory sessionFactoryProduct;
	@Transactional
	public userConfirm getUser(String uuid) {
		// TODO Auto-generated method stub
		userConfirm user;
		Session session= sessionFactoryProduct.openSession();
		Query query = session.createQuery("FROM userConfirm WHERE uuid = :uuid");
		query.setParameter("uuid", uuid);
		user = (userConfirm) query.getSingleResult();
		return user;
	}
	@Transactional
	public void addTempUser(String uuid, userInfo info) {
		// TODO Auto-generated method stub
		userConfirm uconf = new userConfirm();
		uconf.setUuid(uuid);
		uconf.setUsername(info.getUsername());
		uconf.setPassword(info.getPassword());
		uconf.setUname(info.getUname());
		uconf.setUemail(info.getUemail());
		uconf.setUcontact(info.getUcontact());
		uconf.setUaddr(info.getUaddr());
		
		Session session = sessionFactoryProduct.openSession();
		Transaction tx = session.beginTransaction();
		session.save(uconf);
		tx.commit();
		session.close();
	}

}
