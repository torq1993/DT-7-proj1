package com.sunflare.dao;

import com.sunflare.model.userConfirm;
import com.sunflare.model.userInfo;

public interface userConfirmDao {

	public userConfirm getUser(String uuid);
	public void addTempUser(String uuid, userInfo info);
}
