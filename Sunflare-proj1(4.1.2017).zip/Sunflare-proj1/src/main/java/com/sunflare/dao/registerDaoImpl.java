package com.sunflare.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sunflare.model.userConfirm;
import com.sunflare.model.userCredential;
import com.sunflare.model.userInfo;

@Repository
public class registerDaoImpl implements registerDao {

	@Autowired
	SessionFactory sessionFactoryUser;
	
	public String getList() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Transactional
	public void addUser(userConfirm user) {
		// TODO Auto-generated method stub
		userInfo info = new userInfo();
		userCredential uc = new userCredential();
		uc.setUsername(user.getUsername());
		uc.setPassword(user.getPassword());
		info.setUsername(user.getUsername());
		info.setPassword(user.getPassword());
		info.setUname(user.getUname());
		info.setUemail(user.getUemail());
		info.setUcontact(user.getUcontact());
		info.setUaddr(user.getUaddr());
		Session session = sessionFactoryUser.openSession();
		Transaction tx = session.beginTransaction();
		session.save(info);
		session.save(uc);
		tx.commit();
		session.close();
	}

	@Transactional
	public void deleteProduct(int id) {
		// TODO Auto-generated method stub

	}

	@Transactional
	public void editProduct(int id, userInfo user) {
		// TODO Auto-generated method stub

	}

	@Transactional
	public void updateProduct(userInfo tempuser, userInfo user) {
		// TODO Auto-generated method stub

	}

}
