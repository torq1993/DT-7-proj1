package com.sunflare.dao;

import java.util.List;

import com.sunflare.model.Cart;
import com.sunflare.model.Product;
public interface cartDao {
	public List<Cart> addToCart(int pid, List<Cart> cartinfo, int qty);
	public List<Cart> updateQty(int pid, List<Cart> cartinfo, int qty);
	public List<Cart> deleteFromCart(int pid, List<Cart> cartinfo);
	public String viewCart(List<Cart> cartinfo);
}
