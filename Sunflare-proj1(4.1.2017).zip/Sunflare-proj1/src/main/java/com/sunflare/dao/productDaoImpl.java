package com.sunflare.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sunflare.dao.productDao;
import com.google.gson.Gson;
import com.sunflare.model.Product;
@Repository
public class productDaoImpl implements productDao {


	@Autowired
	SessionFactory sessionFactoryProduct;
	
	public String getList() {
		// TODO Auto-generated method stub
		Session session = sessionFactoryProduct.openSession();
		List clist = new ArrayList();
		clist = session.createQuery("FROM Product").getResultList();
		session.close();
		Gson gson = new Gson();
		String gsontojson = gson.toJson(clist);
		return gsontojson;
	}

	@Transactional
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		Session session = sessionFactoryProduct.openSession();
		Transaction tx = session.beginTransaction();
		session.save(product);
		tx.commit();
		session.close();
		
	}

	@Transactional
	public void deleteProduct(int id) {
		// TODO Auto-generated method stub
		Session session = sessionFactoryProduct.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("DELETE FROM Product WHERE pid = :id");
		query.setParameter("id", id);
		query.executeUpdate();
		tx.commit();
		session.close();
	}

	@Transactional
	public void editProduct(int id, Product product) {
		// TODO Auto-generated method stub
		Product tempProduct = new Product();
		tempProduct=getProduct(id);
		updateProduct(tempProduct, product);
	}

	@Transactional
	public void updateProduct(Product tempProduct, Product product) {
		// TODO Auto-generated method stub
		Session session = sessionFactoryProduct.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("UPDATE Product SET pname = :name, pdesc = :desc, price = :price WHERE pid = :id");
		query.setParameter("name", product.getPname());
		query.setParameter("desc", product.getPdesc());
		query.setParameter("price", product.getPrice());
		query.setParameter("id", tempProduct.getPid());
		query.executeUpdate();
		tx.commit();
		session.close();
	}

	@Transactional
	public Product getProduct(int id) {
		// TODO Auto-generated method stub
		Product tempProduct = new Product();
		Session session = sessionFactoryProduct.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("FROM Product WHERE pid = :id");
		query.setParameter("id", id);
		tempProduct= (Product)query.getSingleResult();
		session.close();
		return tempProduct;
	}

}
