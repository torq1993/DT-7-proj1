package com.sunflare.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.sunflare.dao.categoryDao;
import com.sunflare.model.Category;

@Repository
public class categoryDaoImpl implements categoryDao {

	@Autowired
	SessionFactory sessionFactoryCategory;
	
	@Transactional
	public void addCategory(Category category) {
		// TODO Auto-generated method stub

		Session session = sessionFactoryCategory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(category);
		tx.commit();
		session.close();
		
	}


	public String getList() {
		// TODO Auto-generated method stub
		
		Session session = sessionFactoryCategory.openSession();
		List clist = new ArrayList();
		clist = session.createQuery("from Category").getResultList();
		session.close();
		Gson gson = new Gson();
		String gsontojson = gson.toJson(clist);
		return gsontojson;
	}

	@Transactional
	public void deleteCategory(int id) {
		// TODO Auto-generated method stub
		
		Session session = sessionFactoryCategory.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("DELETE FROM Category WHERE cid = :id");
		query.setParameter("id", id);
		query.executeUpdate();
		tx.commit();
		session.close();
	}

	@Transactional
	public void editCategory(int id, Category category) {
		// TODO Auto-generated method stub
		Category tempCategory = new Category();
		tempCategory=getCategory(id);
		updateCategory(tempCategory, category);
	}
	@Transactional
	public void updateCategory(Category tempCategory, Category category) {
		// TODO Auto-generated method stub
		Session session = sessionFactoryCategory.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("UPDATE Category SET cname = :name WHERE cid = :id");
		query.setParameter("name", category.getCname());
		query.setParameter("id", tempCategory.getCid());
		query.executeUpdate();
		tx.commit();
		session.close();
	}

	@Transactional
	public Category getCategory(int id) {
		// TODO Auto-generated method stub
		Category tempCategory = new Category();
		Session session = sessionFactoryCategory.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("FROM Category WHERE cid = :id");
		query.setParameter("id", id);
		tempCategory= (Category)query.getSingleResult();
		session.close();
		return tempCategory;
	}
	

}
