package com.sunflare.dao;



import com.sunflare.model.Category;

public interface categoryDao {
	public String getList();
	public void addCategory(Category category);
	public void deleteCategory(int id);
	public void editCategory(int id, Category category);
	public void updateCategory(Category tempCategory, Category category);
	public Category getCategory(int id);
}
