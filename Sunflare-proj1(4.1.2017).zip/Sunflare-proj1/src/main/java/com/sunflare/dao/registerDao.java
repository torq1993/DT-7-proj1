package com.sunflare.dao;

import com.sunflare.model.userConfirm;
import com.sunflare.model.userInfo;

public interface registerDao {
	public String getList();
	public void addUser(userConfirm user);
	public void deleteProduct(int id);
	public void editProduct(int id, userInfo user);
	public void updateProduct(userInfo tempuser, userInfo user);
}
