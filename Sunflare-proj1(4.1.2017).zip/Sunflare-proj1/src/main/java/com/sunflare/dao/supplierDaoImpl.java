package com.sunflare.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.sunflare.dao.supplierDao;
import com.sunflare.model.Supplier;

@Repository
public class supplierDaoImpl implements supplierDao {

	@Autowired
	SessionFactory sessionFactorySupplier;
	
	@Transactional
	public void addSupplier(Supplier supplier) {
		// TODO Auto-generated method stub

		Session session = sessionFactorySupplier.openSession();
		Transaction tx = session.beginTransaction();
		session.save(supplier);
		tx.commit();
		session.close();
		
	}


	public String getList() {
		// TODO Auto-generated method stub
		
		Session session = sessionFactorySupplier.openSession();
		List slist = new ArrayList();
		slist = session.createQuery("from Supplier").getResultList();
		session.close();
		Gson gson = new Gson();
		String gsontojson = gson.toJson(slist);
		return gsontojson;
	}

	@Transactional
	public void deleteSupplier(int id) {
		// TODO Auto-generated method stub
		
		Session session = sessionFactorySupplier.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("DELETE FROM Supplier WHERE sid = :id");
		query.setParameter("id", id);
		query.executeUpdate();
		tx.commit();
		session.close();
	}

	@Transactional
	public void editSupplier(int id, Supplier supplier) {
		// TODO Auto-generated method stub
		Supplier tempSupplier = new Supplier();
		tempSupplier=getSupplier(id);
		updateSupplier(tempSupplier, supplier);
	}
	public void updateSupplier(Supplier tempSupplier, Supplier supplier) {
		// TODO Auto-generated method stub
		Session session = sessionFactorySupplier.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("UPDATE Supplier SET sname = :name, semail = :email, saddr = :addr WHERE sid = :id");
		query.setParameter("name", supplier.getSname());
		query.setParameter("email", supplier.getSemail());
		query.setParameter("addr", supplier.getSaddr());
		query.setParameter("id", tempSupplier.getSid());
		query.executeUpdate();
		tx.commit();
		session.close();
	}


	public Supplier getSupplier(int id) {
		// TODO Auto-generated method stub
		Supplier tempSupplier = new Supplier();
		Session session = sessionFactorySupplier.openSession();
		Transaction tx = session.beginTransaction();
		Query query = session.createQuery("FROM Supplier WHERE sid = :id");
		query.setParameter("id", id);
		tempSupplier= (Supplier)query.getSingleResult();
		session.close();
		return tempSupplier;
	}
	

}
