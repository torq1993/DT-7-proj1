package com.sunflare.controller;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sunflare.dao.cartDaoImpl;
import com.sunflare.dao.confirmedOrderDaoImpl;
import com.sunflare.dao.productDaoImpl;
import com.sunflare.model.Cart;
import com.sunflare.model.Product;
import com.sunflare.model.billingAddr;
import com.sunflare.model.confirmedOrders;
import com.sunflare.model.userInfo;

@Controller
@SessionAttributes("cartinfo")
public class cartController {
	@Autowired
	cartDaoImpl cartdaoimpl;
	 @Autowired
	 productDaoImpl pdaoimpl;
	 @Autowired 
	 confirmedOrderDaoImpl odaoimpl;
	 @Autowired
		SessionFactory sessionFactoryProduct;
	 @RequestMapping("/addOrder")
	 public ModelAndView addOrder(@ModelAttribute("cartinfo") List<Cart> cartinfo, Authentication auth, billingAddr addr, HttpSession httpsession )
	 {
		 String uname = auth.getName();
		 addr=(billingAddr) httpsession.getAttribute("billingAddr");
		 confirmedOrders order = new confirmedOrders();
		 String cust_order="";
		 for(Cart cart : cartinfo)
		 {
			 cust_order+= cart.getC_pname()+" "+ cart.getQty()+",";
		 }
		 String cust_addr="";
		 cust_addr+=addr.getSt_name()+", "+addr.getArea();
		 order.setUsername(uname);
		 order.setAddr(cust_addr);
		 order.setOrder(cust_order);
		 Session session = sessionFactoryProduct.openSession();
			Transaction tx = session.beginTransaction();
			
			Query query = session.createQuery("FROM userInfo WHERE username = :una");
			query.setParameter("una", uname);
			userInfo user = new userInfo();
			user= (userInfo) query.getSingleResult();
			String phno;
			phno=user.getUcontact();
			order.setPhno(phno);
			session.save(order);
			tx.commit();
			session.close();
			httpsession.setAttribute("cart1", new ArrayList<Cart>());
			
		 ModelAndView mv = new ModelAndView();
		 mv.setViewName("redirect:menu");
		 return mv;
	 }
	 @RequestMapping("/confirmBilling")
	 public ModelAndView confirmBilling()
	 {
		 ModelAndView mv = new ModelAndView("confirmOrder");
		 return mv;
	 }
	 @RequestMapping("/confirmOrder")
	 public ModelAndView confirmOrder(@ModelAttribute billingAddr addr, HttpSession session)
	 {
		 session.setAttribute("billingAddr", addr);
		 ModelAndView mv = new ModelAndView("billing");
		 return mv;
	 }
	 @RequestMapping("/checkout")
	 public ModelAndView checkout(@ModelAttribute("cartinfo")List<Cart> cartinfo, HttpSession session)
	 {
		 
		 session.setAttribute("cart1", cartdaoimpl.viewCart(cartinfo)); 
		 ModelAndView mv = new ModelAndView("Checkout");
		 return mv;
	 }
	@RequestMapping("/addToCart-{pid}-Product-{qty}")
	public ModelAndView addToCart(@PathVariable("pid") int pid,@PathVariable("qty") int qty, @ModelAttribute("cartinfo")List<Cart> cartinfo,RedirectAttributes redirectAttributes, HttpSession session )
	{
		boolean add = true;
		
		for(Cart cinfo : cartinfo )
		{	
			if( cinfo.getC_pid() == pid)
			{
				add= false;
				break;
			}
		}
		if(add == true)
		{	
			
			cartinfo=cartdaoimpl.addToCart(pid,cartinfo,qty);
		}
		else
		{
			cartinfo=cartdaoimpl.updateQty(pid, cartinfo, qty);
		}
		
		redirectAttributes.addFlashAttribute("pList", pdaoimpl.getList());
		redirectAttributes.addFlashAttribute("cList", cartdaoimpl.viewCart(cartinfo));
		session.setAttribute("cartinfo", cartinfo);
		session.setAttribute("cart1", cartdaoimpl.viewCart(cartinfo));
		ModelAndView mv = new ModelAndView();
		mv.setViewName("redirect:/menu");
		return mv;
	}
	@RequestMapping("/delete-{pid}-Product")
	public ModelAndView deleteFromCart(@PathVariable("pid") int pid, @ModelAttribute("cartinfo")List<Cart> cartinfo,RedirectAttributes redirectAttributes, HttpSession session)
	{
		cartinfo=cartdaoimpl.deleteFromCart(pid, cartinfo);
		redirectAttributes.addFlashAttribute("pList", pdaoimpl.getList());
		redirectAttributes.addFlashAttribute("cList", cartdaoimpl.viewCart(cartinfo));
		redirectAttributes.addFlashAttribute("cartinfo", cartinfo);
		session.setAttribute("cart1", cartdaoimpl.viewCart(cartinfo));
		ModelAndView mv = new ModelAndView();
		mv.setViewName("redirect:/menu");
		return mv;
		
	}
	@RequestMapping("/menu")
	public ModelAndView menu(Model model, HttpSession session)
	{
		model.addAttribute("pList", pdaoimpl.getList());
	    if(session.getAttribute("cart1")== null ) {
	    	session.setAttribute("cart1", new ArrayList<Cart>());
	        model.addAttribute("cList", new ArrayList<Cart>());
	        model.addAttribute("cartinfo", new ArrayList<Cart>());
	    }
	    ModelAndView mv = new ModelAndView("menu");		   
		return mv;
	}

	
}
