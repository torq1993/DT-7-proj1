package com.sunflare.controller;


import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;


import com.sunflare.dao.productDaoImpl;
import com.sunflare.dao.categoryDaoImpl;
import com.sunflare.dao.supplierDaoImpl;
import com.sunflare.model.Product;

@Controller
public class productController {
	 @Autowired
	 productDaoImpl pdaoimpl;
	 @Autowired
	 categoryDaoImpl cdaoimpl;
	 @Autowired
	 supplierDaoImpl sdaoimpl;
	   @RequestMapping("/admin/manageProduct")
	   public ModelAndView manageProduct(Model m)
	   {
		   m.addAttribute("product", new Product());
		   m.addAttribute("pList", pdaoimpl.getList());
		   m.addAttribute("cList", cdaoimpl.getList());
		   m.addAttribute("sList", sdaoimpl.getList());
		   ModelAndView mv = new ModelAndView("manageProduct");		   
		   return mv;
		   
	   }
	   @RequestMapping("/admin/addProduct")
	   public String addProduct(@ModelAttribute("product") Product product){
		   System.out.println("inside addproduct");
		   pdaoimpl.addProduct(product);
		   System.out.println("Inside addproduct\n");
		   String path = "C:\\Users\\Karthik\\Desktop\\SunflareWeb\\SunflareWeb\\src\\main\\webapp\\resources\\images\\";
		   path = path+String.valueOf(product.getPid())+".jpg";
		   File f = new File(path);
		   MultipartFile img = product.getPimage();
		   
		   if(!img.isEmpty())
		   {
			   System.out.println("Inside addproduct if\n");
			   try{
				   byte[] bytes = img.getBytes();
				   FileOutputStream fos = new FileOutputStream(f);
				   BufferedOutputStream bos = new BufferedOutputStream(fos);
				   bos.write(bytes);
				   bos.close();
			   }
			   catch(Exception e)
			   {
				   System.out.println("Exception Raised: "+e);
			   }
		   }
		   try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   return "redirect:/admin/manageProduct";
	   }
	   @RequestMapping("/admin/delete-{pid}-Product")
	   public String deleteProduct(@PathVariable int pid){
		   pdaoimpl.deleteProduct(pid);
		   String path = "C:\\Users\\Karthik\\Desktop\\SunflareWeb\\SunflareWeb\\src\\main\\webapp\\resources\\images\\";
		   path = path+String.valueOf(pid)+".jpg";
		   File f = new File(path);
		   f.delete();
		   return "redirect:/admin/manageProduct";
	   }
	   @RequestMapping("/admin/edit-{pid}-Product")
	   public ModelAndView editProduct(@PathVariable int pid, @ModelAttribute("product") Product product){   
		   ModelAndView mv = new ModelAndView("editProduct");
		   mv.addObject(pdaoimpl.getProduct(pid));
		   return mv;
	   }
	   @RequestMapping("/admin/update-{pid}-Product")
	   public String updateProduct(@PathVariable int pid, @ModelAttribute("product") Product product){
		   pdaoimpl.editProduct(pid, product);
		   return "redirect:/admin/manageProduct";
	   }
}
