package com.sunflare.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sunflare.dao.categoryDaoImpl;
import com.sunflare.model.Category;

@Controller
public class categoryController {
	 @Autowired
	 categoryDaoImpl daoimpl;
	
	   @RequestMapping("/admin/manageCategory")
	   public ModelAndView manageCategory(Model m)
	   {
		   m.addAttribute("category", new Category());
		   m.addAttribute("list", daoimpl.getList());
		   ModelAndView mv = new ModelAndView("manageCategory");		   
		   return mv;
		   
	   }
	   @RequestMapping("/admin/addCategory")
	   public String addCategory(@ModelAttribute("category") Category category){
		   daoimpl.addCategory(category);
		   return "redirect:/admin/manageCategory";
	   }
	   @RequestMapping("/admin/delete-{cid}-Category")
	   public String deleteCategory(@PathVariable int cid){
		   daoimpl.deleteCategory(cid);
		   return "redirect:/admin/manageCategory";
	   }
	   @RequestMapping("/admin/edit-{cid}-Category")
	   public ModelAndView editCategory(@PathVariable int cid, @ModelAttribute("category") Category category){   
		   ModelAndView mv = new ModelAndView("editCategory");
		   mv.addObject(daoimpl.getCategory(cid));
		   return mv;
	   }
	   @RequestMapping("/admin/update-{cid}-Category")
	   public String updateCategory(@PathVariable int cid, @ModelAttribute("category") Category category){
		   daoimpl.editCategory(cid, category);
		   return "redirect:/admin/manageCategory";
	   }
}
