package com.sunflare.controller;
import java.util.UUID;
import java.io.IOException;
import java.util.ArrayList;

import javax.persistence.Query;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.sunflare.dao.registerDaoImpl;
import com.sunflare.dao.userConfirmDaoImpl;
import com.sunflare.model.userConfirm;
import com.sunflare.model.userInfo;

@Controller
public class registerController {
	
	@Autowired
	registerDaoImpl rdaoimpl;
	@Autowired
	userConfirmDaoImpl udaoimpl;
	
	
	@Autowired
	SessionFactory sessionFactoryProduct;
	@RequestMapping("/pass")
	public void passUser(HttpServletRequest request,HttpServletResponse response)
	{
		String sn=request.getParameter("ver");
		Session session = sessionFactoryProduct.openSession();
		Query query = session.createQuery("FROM userInfo WHERE username = :una");
		query.setParameter("una", sn);
		ArrayList<userInfo> users = new ArrayList<userInfo>();
		users= (ArrayList<userInfo>) query.getResultList();
		if(!users.isEmpty())
        {    
            try {
			
				 response.getWriter().println("Name already taken");
		        
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
           

        }else {

        	try {
			
				response.getWriter().println("");
	        
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	

        }
		session.close();
	}
	@RequestMapping(value="/confEmail")
	public String confEmail(@ModelAttribute("user") userInfo user, Model m) throws EmailException
	{
		String uuid = UUID.randomUUID().toString();
		Email email = new SimpleEmail();
		udaoimpl.addTempUser(uuid,user);
		email.setHostName("smtp.googlemail.com");
		email.setSmtpPort(465);
		email.setSSLOnConnect(true);
		email.setFrom("torq1993@gmail.com");
		email.setAuthenticator(new DefaultAuthenticator("torq1993@gmail.com", "urfrndbkram1993"));
		email.setSubject("test");
		email.setMsg("http://localhost:8480/SunflareWeb/adduser-"+uuid);
		email.addTo("torqsama1993@gmail.com");
		email.send();
		return "addUser";
	}
	
	@RequestMapping(value="/adduser-{uuid}")
	public String addUser(@PathVariable String uuid,RedirectAttributes ra)
	{
		if(udaoimpl.getUser(uuid) != null)
		{
			rdaoimpl.addUser(udaoimpl.getUser(uuid));
			String msg = "Registration Successful";
			ra.addFlashAttribute("msg",msg);
			ModelAndView mv= new ModelAndView();
		}
		return "redirect:/";
		
		
	}
	

}
