package com.sunflare.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.sunflare.dao.cartDaoImpl;
import com.sunflare.dao.productDaoImpl;
import com.sunflare.model.Product;
import com.sunflare.model.userInfo;

@Controller
public class dispatcherController{
	 @Autowired
	 productDaoImpl pdaoimpl;
	 @Autowired
	 cartDaoImpl cartdaoimpl;

		@RequestMapping("/")
		public String index(){
			return "index";
		}
	   @RequestMapping("/aboutUs")
	   public String aboutUs(ModelMap model){
		   return "aboutUs";
	   }
	   
	   @RequestMapping("/login")
	   public String login(){
		   return "login";
	   }
	   
	   @RequestMapping(value="/register", method=RequestMethod.GET)
	   public String register(Model m){
		   userInfo ui = new userInfo();
		   m.addAttribute("user", ui);
		   return "register";
	   }
	   
	   @RequestMapping("/contactus")
	   public String contactus(){
		   return "contactus";
	   }
	   
	   @RequestMapping("/403")
	   public String accessDenied(Model m){
		   m.addAttribute("error","Access Denied");
		   System.out.println("inside 403");
		   return "redirect:/";
	   }
	   

	   @RequestMapping("/logout")
	   public String logout(HttpServletRequest request, HttpServletResponse response){
		   Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		   if(auth != null)
		   {
			   new SecurityContextLogoutHandler().logout(request, response, auth);
		   }
		   return "redirect:/";
	   }
	/*   @RequestMapping("/products")
	   public ModelAndView products(){
		   Product prod = new Product();
		   ModelAndView mv = new ModelAndView("products");
		   mv.addObject("model", prod.populateData());
		   return mv;
	   }*/
}