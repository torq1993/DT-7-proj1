package com.sunflare.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Transient;
import javax.validation.constraints.Size;

@Entity
public class userInfo {
	@Id
	@GeneratedValue
	@Column(name= "U_ID")
	private int uid;
	@Column(name="USERNAME")
	private String username;
	@Column(name="U_NAME")
	private String uname;
	@Column(name= "U_CONTACT")
	private String ucontact;
	@Column(name= "U_EMAIL")
	private String uemail;
	@Column(name= "U_ADDR")
	private String uaddr;
	@Transient
	private String password;
	public String getUemail() {
		return uemail;
	}
	public void setUemail(String uemail) {
		this.uemail = uemail;
	}
	public String getUaddr() {
		return uaddr;
	}
	public void setUaddr(String uaddr) {
		this.uaddr = uaddr;
	}
	public String getUcontact() {
		return ucontact;
	}
	public void setUcontact(String ucontact) {
		this.ucontact = ucontact;
	}
	public String getPassword() {
		return password;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
