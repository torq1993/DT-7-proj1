package com.sunflare.model;


public class productInfo {

	private int pid;
	private String pname;
	private String pdesc;
	private double price;
	private String sname;
	private String cname;
	private String ptype;
	public productInfo(Product product)
	{
		this.pid=product.getPid();
		this.pname=product.getPname();
		this.price=product.getPrice();
		this.sname=product.getSname();
		this.cname=product.getCname();
		this.ptype=product.getPtype();
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPdesc() {
		return pdesc;
	}
	public void setPdesc(String pdesc) {
		this.pdesc = pdesc;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getPtype() {
		return ptype;
	}
	public void setPtype(String ptype) {
		this.ptype = ptype;
	}
	
}
