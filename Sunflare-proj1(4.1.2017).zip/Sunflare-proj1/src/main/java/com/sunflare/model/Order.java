package com.sunflare.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Order {
	@Id
	@GeneratedValue
	@Column(name="O_ID")
	private int oid;
	@Column(name="C_ID")
	private int cid;
	@Column(name="C_NAME")
	private int cname;
	
}
