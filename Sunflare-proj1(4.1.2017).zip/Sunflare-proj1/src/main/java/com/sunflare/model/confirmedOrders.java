package com.sunflare.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class confirmedOrders {

	@Id
	@GeneratedValue
	@Column(name="O_ID")
	private int oid;
	@Column(name="O_UNAME")
	private String username;
	@Column(name="ORDERS")
	private String order;
	@Column(name="ADDRESS")
	private String addr;
	@Column(name="PH_NO")
	private String phno;
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getPhno() {
		return phno;
	}
	public void setPhno(String phno) {
		this.phno = phno;
	}
	
}
